<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sewa Kamar</title>

    <link rel="stylesheet" href="vendors/bootstrap/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="vendors/boxicons/css/boxicons.min.css"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css"/>

    <link rel="stylesheet" href="styles.css"/>

</head>
<body>

</head>


    
    <nav class="navbar navbar-expand-lg bg-white">
        <img src="images/logo1.png" width="5%" height="44px">
        <div class="container"> 
          <a class="navbar-brand fw-bold">Kontrakan 95</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <a href="home.php" class="nav-link" aria-current="page">Beranda</a>
              </li>
             
              <li class="nav-item">
                <a href="sewa.php" class="nav-link active" aria-current="page">Sewa</a>
              </li>
              <li class="nav-item">
                <a href="Tentang.php" class="nav-link" aria-current="page">Informasi Kamar</a>
              </li>
              <li class="nav-item">
                <a href="login.php" class="nav-link" aria-current="page">Login</a>
              </li>

             
              
              </li>
          </div>
        </div>
      </nav>

      <section class="albums-section" id="albums">
    <div class="container">
        <h2 class=" text-orange section-title mb-5">Kontrakan 95 </h2>

   
        <h2 class="fw-semibold mb-2">Blok 1</h2>
        <img src="images/1 (2).jpeg" width="30%" height="200px"> <br> <br>
        <h6 class="text-black fw-semibold"> Di blok ini terdapat 5 kamar, yaitu:
            Kamar A , Kamar B, Kamar C, Kamar D, Kamar E. <br>
            Blok Ini adalah blok yang mempunyai 2 lantai/tingkat, <br>
            terletak di paling depan, dan mempunyai garasi motor sendiri.</h6> 
            <h7>  <a href="Kamar A-E.php" class="text-orange">Sewa Kamar</h7> </a>


        <div class="card"></div>
        <div class="card-body"></div>
        <h2 class="fw-semibold mb-2">Blok 2</h2>
        <img src="images/2 (2).jpeg" width="30%" height="200px"> <br> <br>
        <h6 class="text-black fw-semibold"> Di blok ini hanya terdapat 4 kamar, yaitu:
            Kamar F, Kamar G, Kamar H, Kamar I. <br>
            Blok Ini adalah blok yang terletak di tengah tengah antara blok 1 dan blok 3.<br>
            Blok ini juga adalah blok yang paling ramai di banding blok blok yang lainnya.</h6> 
            <h7>  <a href="KamarF-I.php" class="text-orange">Sewa Kamar</h7> </a>
       


        <div class="card"></div>
        <div class="card-body"></div>
        <h2 class="fw-semibold mb-2">Blok 3</h2>
        <img src="images/3 (2).jpeg" width="30%" height="200px"> <br> <br>
        <h6 class="text-black fw-semibold"> Sama dengan blok yang ke 2, blok ini hanya mempunyai
            kamar yang berjumlah <br> 4 kamar, yaitu:
            Kamar J, Kamar K, Kamar L, Kamar M. <br>
            Blok Ini adalah blok yang paling minimalis dan juga dengan harga yang paling murah.<br>
            Jika di bandingkan dengan blok yang lainnya, blok ini adalah blok yang paling banyak peminatnya,<br> 
            kamar-kamarnya tidak pernah ada yang kosong, Jika ada yang keluar, pasti langsung ada yang masuk.</h6>  
            <h7>  <a href="KamarJ-M.php" class="text-orange">Sewa Kamar</h7> </a>

        <div class="d-flex align-items-center justify-content-end gap-3">
        </div>
    </div>
</section>

<footer class="py-3">
    <div class="container">
        <p class="text-white fs-7 mb-0">Copyright &copy; Ciburuy 95 X mclhrooo</p>

    </div>

</footer>

      
    
<script src="vendors/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>


</body>
</html>