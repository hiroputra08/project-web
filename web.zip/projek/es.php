<div class="form-group">
                              <label class="col-sm-2 col-sm-2 control-label text-right">Jenis Kelamin</label>
                              <div class="col-sm-10">
                                  <select   class="form-control" name="jk" required >
                                    <option value="">Silahkan Pilih</option>
                                    <option value="Laki-laki">Sudah Tersewa</option>
                                    <option value="Perempuan">Masih Ada</option>
                                  </select>
                              </div>
                          </div>