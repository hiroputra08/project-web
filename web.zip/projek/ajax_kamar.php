<?php 
include("koneksi.php");
$kamar = $_POST['id_no_blok'];
$tampil=mysqli_query($koneksi,"SELECT * FROM keterangan_kamar WHERE id_blok ='$nomor'");
$jml=mysqli_num_rows($tampil);
 
if($jml > 0){    
    while($r=mysqli_fetch_array($tampil)){
        ?>
        <option value="<?php echo $r['id'] ?>"><?php echo $r['nama_kamar'] ?></option>
        <?php        
    }
}else{
    echo "<option selected>- Data Wilayah Tidak Ada, Pilih Yang Lain -</option>";
}
 
?>