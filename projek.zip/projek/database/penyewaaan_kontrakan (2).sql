-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 16 Feb 2024 pada 04.45
-- Versi server: 10.4.24-MariaDB
-- Versi PHP: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `penyewaaan_kontrakan`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `admin` int(11) NOT NULL,
  `nama_admin` varchar(30) NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`admin`, `nama_admin`, `username`, `password`) VALUES
(1, 'hiro', 'admin', '21232f297a57a5a743894a0e4a801fc3');

-- --------------------------------------------------------

--
-- Struktur dari tabel `blok`
--

CREATE TABLE `blok` (
  `id_no_blok` int(2) NOT NULL,
  `nomor` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `blok`
--

INSERT INTO `blok` (`id_no_blok`, `nomor`) VALUES
(1, 1),
(2, 2),
(3, 3);

-- --------------------------------------------------------

--
-- Struktur dari tabel `keterangan_kamar`
--

CREATE TABLE `keterangan_kamar` (
  `id` int(3) NOT NULL,
  `id_blok` int(2) NOT NULL,
  `nama_kamar` varchar(20) NOT NULL,
  `harga_kamar` int(10) NOT NULL,
  `Status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `keterangan_kamar`
--

INSERT INTO `keterangan_kamar` (`id`, `id_blok`, `nama_kamar`, `harga_kamar`, `Status`) VALUES
(0, 1, 'Kamar A', 500000, 'Sudah Tersewa'),
(10, 3, 'Kamar K', 450000, 'Masih Ada'),
(11, 3, 'Kamar L', 450000, 'Masih Ada'),
(12, 3, 'Kamar M', 450000, 'Masih Ada'),
(111, 1, 'Kamar B', 500000, 'Sudah Tersewa'),
(222, 1, 'Kamar C', 500000, 'Sudah Tersewa'),
(333, 1, 'Kamar D', 500000, 'Sudah Tersewa'),
(444, 1, 'Kamar E', 500000, 'Sudah Tersewa'),
(555, 2, 'Kamar F', 500000, 'Masih Ada'),
(666, 2, 'Kamar G', 500000, 'Masih Ada'),
(777, 2, 'Kamar H', 500000, 'Masih Ada'),
(888, 2, 'Kamar I', 500000, 'Sudah Tersewa'),
(999, 3, 'Kamar J', 450000, 'Sudah Tersewa');

-- --------------------------------------------------------

--
-- Struktur dari tabel `penyewa`
--

CREATE TABLE `penyewa` (
  `id` int(3) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `no_hp` varchar(20) NOT NULL,
  `nama_kamar` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `penyewa`
--

INSERT INTO `penyewa` (`id`, `nama`, `no_hp`, `nama_kamar`) VALUES
(56, 'Desta', '344', 'Kamar B'),
(57, 'Hiro Hendra', '089603458141', 'Kamar J'),
(58, 'Aan resing', '089834561209', 'Kamar A'),
(59, 'Hendra', '089603458142', 'Kamar E'),
(60, 'Ayi Suherman', '089603217765', 'Kamar D'),
(61, 'Beni Jawara', '089577698871', 'Kamar C');

-- --------------------------------------------------------

--
-- Stand-in struktur untuk tampilan `vpenyewa`
-- (Lihat di bawah untuk tampilan aktual)
--
CREATE TABLE `vpenyewa` (
);

-- --------------------------------------------------------

--
-- Struktur untuk view `vpenyewa`
--
DROP TABLE IF EXISTS `vpenyewa`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vpenyewa`  AS SELECT `penyewa`.`id` AS `id`, `penyewa`.`nama` AS `nama`, `penyewa`.`no_hp` AS `no_hp`, `penyewa`.`id_kamar` AS `id_kamar`, `keterangan_kamar`.`nama_kamar` AS `nama_kamar` FROM (`penyewa` join `keterangan_kamar`) WHERE `penyewa`.`id_kamar` = `keterangan_kamar`.`id` ORDER BY `keterangan_kamar`.`nama_kamar` ASC  ;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin`);

--
-- Indeks untuk tabel `blok`
--
ALTER TABLE `blok`
  ADD PRIMARY KEY (`id_no_blok`);

--
-- Indeks untuk tabel `keterangan_kamar`
--
ALTER TABLE `keterangan_kamar`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_blok` (`id_blok`);

--
-- Indeks untuk tabel `penyewa`
--
ALTER TABLE `penyewa`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `admin`
--
ALTER TABLE `admin`
  MODIFY `admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `blok`
--
ALTER TABLE `blok`
  MODIFY `id_no_blok` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT untuk tabel `penyewa`
--
ALTER TABLE `penyewa`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `keterangan_kamar`
--
ALTER TABLE `keterangan_kamar`
  ADD CONSTRAINT `keterangan_kamar_ibfk_1` FOREIGN KEY (`id_blok`) REFERENCES `blok` (`id_no_blok`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
