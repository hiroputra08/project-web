<?php
    include 'koneksi.php';

    $id = $_GET ['id'];
    mysqli_query($koneksi, "delete from keterangan_kamar where id='$id'");
    header('Location:ketkamar-admin.php');
?>