<?php include 'koneksi.php' ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Mmebuat Select Option Dinamis Dengan Ajax</title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" crossorigin="anonymous">
 
</head>
<body>
	<div>
		<form action="">
			<div >
				<label>Id Kamar:</label>
				<select  name="nomor" id="nomor" required>
					<option value="">--Pilih--</option>
					<?php
					$nomor = mysqli_query($koneksi,"select * from keterangan_kamar");
					while($f = mysqli_fetch_array($nomor)){
						?>
						<option value="<?php echo $f['id'] ?>"><?php echo $f['id']; ?></option>
						<?php
					}
					?>
				</select>
			</div>
			<div class="form-group">
				<label>Nama Kamar</label>
				<select class="form-control" name="nama_kamar" id="nama_kamar" required>					
                <option value="">--Nama Kamar--</option>

                
					

				</select>
			</div>			
			<button type="submit" class="btn btn-primary">Submit</button>
		</form>
	</div>
	
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
	
	
 
	<script type="text/javascript">
		$('#nomor').change(function() { 
			var nomor = $(this).val(); 
			$.ajax({
				type: 'POST', 
				url: 'ajax_kamar.php', 
				data: 'id=' + nomor, 
				success: function(response) { 
					$('#nama_kamar').html(response); 
				}
			});
		});
 
	</script>
 
</body>
</html>