<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home Page</title>

    


    <link rel="stylesheet" href="vendors/bootstrap/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="vendors/boxicons/css/boxicons.min.css"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.css"/>

    <link rel="stylesheet" href="styles.css"/>
</head>

<head>
    <body>

    
    <nav class="navbar navbar-expand-lg bg-purple">
    <img src="images/logo1.png" width="5%" height="44px">
        <div class="container"> 
          <a class="navbar-brand fw-bold">Kontrakan 95</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <a href="home.php" class="nav-link active" aria-current="page" >Beranda</a>
              </li>
             
              <li class="nav-item">
                <a href="sewa.php" class="nav-link" aria-current="page" >Sewa</a>
              </li>
              <li class="nav-item">
                <a href="Tentang.php" class="nav-link" aria-current="page" >Informasi Kamar</a>
              </li>
              <li class="nav-item">
                <a href="login.php" class="nav-link" aria-current="page" >Login</a>
              </li>

              </li>

          </div>
        </div>
      </nav>

      

<section class="header-section" id="header">
    <div class="container">
        <div class="row align-items-center justify-content-between">
            <div class="col-md-6">
                <h1 class="header-title text-uppercase fw-bold mb-5">
                    <br class="d-none d-md-block"></h1>

                    <a href="naurav1.html" class="header-skill d-inline-flex align-items-center gap-2">

                    
                    </a>
                    <div class="d-flex align-items-center gap-4 mt-5">
                        <div class="d-flex align-items-center gap-2">

                            <h2 class="header-skill fw-bold">Gratis</h2>
                            <p class="text-secondary fs-7 mb-0">Steam Motor</p>
                            
                        </div>
                    <div class="d-flex align-items-center gap-4 mt-5">
                        <div class="d-flex align-items-center gap-2">

                            <h2 class="header-skill fw-bold">Gratis</h2>
                            <p class="text-secondary fs-7 mb-0">Token Air</p>
                            
                        </div>

                    </div>
            </div>
        </div>

        
        <div class="col-md-5">
            <img src="images/siteplan.jpg" class="header-img" alt="">
        </div>
        
        

    </div>
</section>

<section class="albums-section" id="albums">
    <div class="container">
        <h4 class="text-orange section-title mb-3">Kontrakan 95 </h4>
        <h6 class="text-black section-title mb-3">Syarat & Ketentuan</h6>

    
        <h7> <p class="text-secondary mb-3">-Maksimal Mempunyai 2 anak (untuk yang berkeluarga). </p> </h7>
        <h7> <p class="text-secondary mb-3">-Satu Kamar hanya bisa ditempati maksimal 5 orang (terkecuali tamu yang tidak menetap lama). </p> </h7>
        <h7> <p class="text-secondary mb-3">-Menunjukkan surat/buku nikah untuk yang mengaku sudah berkeluarga. </p> </h7>
        <h7> <p class="text-secondary mb-3">-Tidak mengambil hak tempat parkir orang lain. </p> </h7>
        <h7> <p class="text-secondary mb-3">-Bebas kebisingan pukul 22.00 WIB. </p> </h7>
        <h7> <p class="text-secondary mb-3">-Di perbolehkan menggunakan knalpot bising asal sewajarnya. </p> </h7>
        <h7> <p class="text-secondary mb-3">-Menunggak uang sewa selama 2 bulan, akan diminta/dikeluarkan. </p> </h7>
        
</section>

<section class="spek-section" id="skills">
    <div class="container">
        <div class="row align-items-center justify-content-between">
            <div class="col md-6">
                <p class="text-orange fw-semibold">Rating</p>
                <h2 class="section-title text-white mb-5">Kontrakan 95</h2>

                <div class="mb-4">
                    <div class="d-flex align-items-center justify-content-between mb-2">
                        <p class="Text-uppercase fw-bold mb-0">Kenyamanan</p>
                        <p class="Text-uppercase fw-bold mb-0">99%</p>
                    </div>
                    <div class="progress-bar">
                        <span class="progress" style="width: 99%"></span>
                    </div>
                </div>
                <div class="mb-4">
                    <div class="d-flex align-items-center justify-content-between mb-2">
                        <p class="Text-uppercase fw-bold mb-0">Ketentraman</p>
                        <p class="Text-uppercase fw-bold mb-0">99%</p>
                    </div>
                    <div class="progress-bar">
                        <span class="progress" style="width: 99%"></span>
                    </div>
                </div>
                <div class="mb-4">
                    <div class="d-flex align-items-center justify-content-between mb-2">
                        <p class="Text-uppercase fw-bold mb-0">Keamanan</p>
                        <p class="Text-uppercase fw-bold mb-0">100%</p>
                    </div>
                    <div class="progress-bar">
                        <span class="progress" style="width: 100%"></span>
                    </div>
                </div>
                <div class="mb-4">
                    <div class="d-flex align-items-center justify-content-between mb-2">
                        <p class="Text-uppercase fw-bold mb-0">Fasilitas</p>
                        <p class="Text-uppercase fw-bold mb-0">100%</p>
                    </div>
                    <div class="progress-bar">
                        <span class="progress" style="width: 100%"></span>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>

<section class="timeline-section" id="timeline">
    <div class="container">
        <p class="text-orange fw-semibold">Rincian</p>
        <h2 class="section-title mb-5">Harga Kamar</h2>

        <div class="row py-3 border-bottom working-period-item">
            <div class="col md-4">Kamar A-E</div>
            <div class="col md-4">RP.500.000 </div>
           <a  href="Tentang.php" class="text-orange">Detail</a> 
            

        </div>
        <div class="row py-3 border-bottom working-period-item">
            <div class="col md-4">Kamar F-K</div>
            <div class="col md-4">RP.500.000</div>
            <a href="Tentang.php" class="text-orange">Detail</a>
           

        </div>
        
        <div class="row py-3 border-bottom working-period-item">
            <div class="col md-4">Kamar L-N</div> 
            <div class="col md-4">RP.450.000</div>
            <a href="Tentang.php" class="text-orange">Detail</a>
            

        </div>
       
</div>
</section>


<footer class="py-3">
    <div class="container">
        <p class="text-white fs-7 mb-0">Copyright &copy; Ciburuy 95 X mclhrooo</p>

    </div>

</footer>


      
    
<script src="vendors/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/swiper@8/swiper-bundle.min.js"></script>


</body>
</html>