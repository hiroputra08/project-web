<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit</title>

    <link rel="stylesheet" href="vendors/bootstrap/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="vendors/boxicons/css/boxicons.min.css"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css"/>

    <link rel="stylesheet" href="styles.css"/>
</head>

</head>
<body>

<nav class="navbar navbar-expand-lg bg-purple">
    <img src="images/logo1.png" width="5%" height="44px">
        <div class="container"> 
          <a class="navbar-brand fw-bold">Kontrakan 95</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <a href="penyewa-admin.php" class="nav-link active" aria-current="page" >Penyewa</a>
              </li>
             
              <li class="nav-item">
                <a href="ketkamar-admin.php" class="nav-link" aria-current="page" >Keterangan Kamar</a>
              </li>
              <li class="nav-item">
                <a href="login.php" class="nav-link" aria-current="page" >Login</a>
              </li>

              </li>

          </div>
        </div>
      </nav>


    
<?php
	include 'koneksi.php';
	$id = $_GET['id'];
	$data = mysqli_query($koneksi,"select * from keterangan_kamar where id='$id'");
	while($d = mysqli_fetch_array($data)){
		?>
		<form method="post" action="update.php">
			<table>
				<tr>			
					<td>Nama Kamar</td>
					<td>
						<input type="hidden" name="id" value="<?php echo $d['id']; ?>">
						<input type="text" name="nama_kamar" value="<?php echo $d['nama_kamar']; ?>">
					</td>
				</tr>
				<tr>
					<td>Nomor Blok</td>
					<td><input type="text" name="id_blok" value="<?php echo $d['id_blok']; ?>"></td>
				</tr>
				<tr>
					<td>Harga</td>
					<td><input type="text" name="harga_kamar" value="<?php echo $d['harga_kamar']; ?>"></td>
				</tr>
				<tr>
					<td>Status</td>
					<td><input type="text" name="Status" value="<?php echo $d['Status']; ?>"></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" value="SIMPAN"></td>
				</tr>		
			</table>
		</form>
		<?php 
	}
	?>

<script src="vendors/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>


</body>
</html>