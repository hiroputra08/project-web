<?php
include 'koneksi.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Informasi 95</title>

    <link rel="stylesheet" href="vendors/bootstrap/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="vendors/boxicons/css/boxicons.min.css"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css"/>

    <link rel="stylesheet" href="styles.css"/>


</head>
<body>
    
<nav class="navbar navbar-expand-lg bg-purple">
    <img src="images/logo1.png" width="5%" height="44px">
        <div class="container"> 
          <a class="navbar-brand fw-bold">Kontrakan 95</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <a href="penyewa-admin.php" class="nav-link" aria-current="page" >Penyewa</a>
              </li>
             
              <li class="nav-item">
                <a href="ketkamar-admin.php" class="nav-link active" aria-current="page" >Keterangan Kamar</a>
              </li>
              <li class="nav-item">
                <a href="logout.php" class="nav-link" aria-current="page" >Logout</a>
              </li>

              </li>

          </div>
        </div>
      </nav>


<br>


      <style>
        table, th, td {
  border: 1px solid;
}
table, th, td {
  border: 1px solid;
}
table {
  width: 100%;
  text-align: center;
}

      </style>
      <form action="ketkamar-admin.php" method="get">
    <label>Cari :</label>
    <input type="text" name="cari">
    <input type="submit" value="Cari">
</form>

<?php 
if(isset($_GET['cari'])){
    $cari = $_GET['cari'];
    echo "<b>Hasil pencarian : ".$cari."</b>";
}
?>

<table border="1">
    <tr>
        <th>No</th>
        <th>Id</th>
        <th>Nomor Blok</th>
        <th>Nama Kamar</th>
        <th>Harga Kamar</th>
        <th>Status</th>
        <th>Aksi</th>
    </tr>
    <?php 
    if(isset($_GET['cari'])){
        $cari = $_GET['cari'];
        $query = "SELECT * FROM keterangan_kamar WHERE nama_kamar LIKE '%$cari%' or id_blok like '%$cari%' order by id";
    } else {
        $query = "SELECT * FROM keterangan_kamar";
    }
    
    $result = mysqli_query($koneksi, $query);
    $no = 1;
    while($d = mysqli_fetch_array($result)){
    ?>
    <tr> 
        <td><?php echo $no++; ?></td>
        <td><?php echo $d['id']; ?></td>
        <td><?php echo $d['id_blok']; ?></td>
        <td><?php echo $d['nama_kamar']; ?></td>
        <td><?php echo $d['harga_kamar']; ?></td>
        <td><?php echo $d['Status']; ?></td>

        <td>
                <a href="formedit.php?id=<?php echo $d['id']; ?>">Edit</a>
                <a href="hapus.php?id=<?php echo $d["id"]; ?>" onclick="return confirm('Apakah Kamu Yakin Ingin Menghapus Data Ini')"><i class="btn btn-primary"></i>Hapus</a>
            </td>

    </tr>
    <?php }
     ?>
</table>

<style>
    table, th, td {
        border: 1px solid;
    }
    table, th, td {
        border: 1px solid;
    }
    table {
        width: 100%;
        text-align: center;
    }
</style>
              
                
                
				
			</tr>
			<?php 
		
		?>
	</table>

<br>
<br>
<br>
<br>
<br>
<br>
<br>


  </div>
</section>

<footer class="py-3">
    <div class="container">
        <p class="text-white fs-7 mb-0">Copyright &copy; Ciburuy 95 X mclhrooo</p>

    </div>

</footer>

      <script src="vendors/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>


</body>
</html>