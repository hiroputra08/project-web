<?php 
// koneksi database
include 'koneksi.php';
 
// menangkap data yang di kirim dari form
$id = $_POST['id'];
$nama_kamar = $_POST['nama_kamar'];
$id_blok = $_POST['id_blok'];
$harga_kamar = $_POST['harga_kamar'];
$Status = $_POST['Status'];


 
// update data ke database
mysqli_query($koneksi,"update keterangan_kamar set nama_kamar='$nama_kamar', id_blok='$id_blok', harga_kamar='$harga_kamar', Status='$Status'  where id='$id'");
 
// mengalihkan halaman kembali ke index.php
header("Location:ketkamar-admin.php");
 
?>