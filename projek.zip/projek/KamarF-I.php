<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kamar F-i</title>

    <link rel="stylesheet" href="vendors/bootstrap/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="vendors/boxicons/css/boxicons.min.css"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css"/>

    <link rel="stylesheet" href="styles.css"/>

</head>
<body>
    
<nav class="navbar navbar-expand-lg bg-white">
        <img src="images/logo1.png" width="5%" height="44px">
        <div class="container"> 
          <a class="navbar-brand fw-bold">Kontrakan 95</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <a href="home.php" class="nav-link" aria-current="page" >Beranda</a>
              </li>
             
              <li class="nav-item">
                <a href="sewa.php" class="nav-link active" aria-current="page" >Sewa</a>
              </li>
              <li class="nav-item">
                <a href="Tentang.php" class="nav-link" aria-current="page" >Informasi Kamar</a>
              </li>
              <li class="nav-item">
                <a href="login.php" class="nav-link" aria-current="page" >Login</a>
              </li>
             
              
              </li>
          </div>
        </div>
      </nav>

      <section class="albums-section" id="albums">
    <div class="container">
    <a class="navbar-brand fw-bold">Sewa Kamar</a> 
        <p class="text-orange fw-semibold ">Kontrakan 95</p>
        <h2 class="section-title mb-5"></h2>
        <h6 class="fw-semibold">Kamar F</h6>
        <a href="konfirmasisewa.php" class="text-orange">Sewa</a>
        <div class="card"></div>
        <div class="card-body"></div>
        <h6 class="fw-semibold">Kamar G</h6>
        <a href="konfirmasisewa.php" class="text-orange">Sewa</a>
        <div class="card"></div>
        <div class="card-body"></div>
        <h6 class="fw-semibold">Kamar H</h6>
        <a href="konfirmasisewa.php" class="text-orange">Sewa</a>
        <div class="card"></div>
        <div class="card-body"></div>
        <h6 class="fw-semibold">Kamar I</h6>
        <a href="konfirmasisewa.php" class="text-orange">Sewa</a>

        </div>
</section>

        
     
       
        <br>
        <br>
        <br>
        <br>

        <br>
        <br>
        <br>
        <br>


        <footer class="py-3">
    <div class="container">
        <p class="text-white fs-7 mb-0">Copyright &copy; Ciburuy 95 X mclhrooo</p>

    </div>

</footer>



      <script src="vendors/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>

</body>
</html>