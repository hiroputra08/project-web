
<style>
    .css {
            position:absolute;
            top: 30%;
            left: 50%;
            transform: translate(-50%, -50%);
            
            
        }

        h1 {
            font-size: large;
        
         

        }
        body {
            font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
            color: orangered;
            background-color: white;
            

          
            
        }
</style>



<?php 
 
include 'koneksi.php';
 
error_reporting(0);
 
session_start();
 
if (isset($_SESSION['username'])) {
    header("Location: penyewa-admin.php");
}
 
if (isset($_POST['submit'])) {
    $username = $_POST['username'];
    $password = md5($_POST['password']);
 
    $sql = "SELECT * FROM admin WHERE username='$username' AND password='$password'";
    $result = mysqli_query($koneksi, $sql);
    if ($result->num_rows > 0) {
        $row = mysqli_fetch_assoc($result);
        $_SESSION['username'] = $row['username'];
        header("Location: penyewa-admin.php");
    } else {
        echo "<script>alert('Email atau password Anda salah. Silahkan coba lagi!')</script>";
    }
}
 
?>
 



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Pages</title>

<link rel="stylesheet" href="vendors/bootstrap/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="vendors/boxicons/css/boxicons.min.css"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css"/>

    <link rel="stylesheet" href="styles.css"/>

</head>
<body>

<nav class="navbar navbar-expand-lg bg-white">
        <img src="images/logo1.png" width="5%" height="44px"> <br> <br>
        <div class="container"> 
          <a class="navbar-brand fw-bold">Kontrakan 95</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <a href="home.php" class="nav-link" aria-current="page">Beranda</a>
              </li>
             
              <li class="nav-item">
                <a href="sewa.php" class="nav-link" aria-current="page">Sewa</a>
              </li>
              <li class="nav-item">
                <a href="Tentang.php" class="nav-link" aria-current="page">Informasi Kamar</a>
              </li>
              <li class="nav-item">
                <a href="login.php" class="nav-link active" aria-current="page">Login</a>
              </li>
             
              
              </li>
          </div>
        </div>
      </nav>

      <br>
      <br>

      
</body>


<body>
      <div class="alert alert-warning" role="alert">
        <?php echo $_SESSION['error']?>
    </div>

    <img src="images/logo1.png" width="auto" height="100px"> <br> <br>
       
            <h1>Kontrakan 95</h1> <br>
            <div class="container">
        <form action="" method="POST">
            <div class="input-group">
                <input type="username" placeholder="Username" name="username" value="<?php echo $username; ?>" required>
            </div>
            <br>
      <br>
      <br>
            <div class="input-group">
                <input type="password" placeholder="Password" name="password" value="<?php echo $_POST['password']; ?>" required>
            </div>

            <br>
      
            <div class="input-group">
                <button name="submit" class="btn">Masuk</button>
            </div>

        </form>
    </div>

    </body>

    <br>
      <br><br>
      <br><br>
      <br>

    <footer class="py-3">
    <div class="container">
        <p class="text-white fs-7 mb-0">Copyright &copy; Ciburuy 95 X mclhrooo</p>

    </div>

    
    

</footer>

        
<script src="vendors/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>

</body>
</html>